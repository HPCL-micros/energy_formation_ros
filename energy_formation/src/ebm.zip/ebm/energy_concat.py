import os
from functools import reduce
from operator import mul
#os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
import ObjectEnv as oe
import random
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow.contrib.slim as slim
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
from EBMloader import EnergyLoader
from tensorflow.python.platform import flags

min_index = -2.0
max_index = 2.0
#TODO: not implemented. waiting for localization.
if __name__ == '__main__':
    squire_energy = EnergyLoader('model/fixed_squire_anchor')
    triangle_energy = EnergyLoader('model/fixed_triangle_anchor')
    #test squire
    x = np.random.uniform(min_index, max_index, size=(4 * 2)).tolist()
    test_anchor = np.random.uniform(min_index, max_index / 2.0, size=(1 * 2)).tolist()
    env = oe.ObjectEnv(min_index, max_index)
    env.clear()
    env.set_from_x_short(x)
    env.show()
    plt.waitforbuttonpress()
    for i in range(0, 500):
        x, x_grads, e_x =squire_energy.optimize([x],[test_anchor]) #sess.run([x_next, grads, energy_pos], feed_dict={x_pos: [x], x_anchor: [test_anchor]})
        print("energy = " + str(e_x) + " anchor = " + str(test_anchor))
        # print (x)
        # print (x_grads)
        x = np.squeeze(x)
        env.clear()
        env.set_from_x_short(x)
        env.show()
        # plt.waitforbuttonpress()
        plt.pause(0.05)
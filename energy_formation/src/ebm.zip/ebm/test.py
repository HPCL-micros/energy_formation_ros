import ObjectEnv as oe
import random
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow.contrib.slim as slim


def fc(input, output_shape, activation_fn=tf.nn.relu, name="fc"):
    output = slim.fully_connected(input, int(output_shape), activation_fn=activation_fn)
    return output


class EnergyFunction:  #(n*n-1)*dim*2
    def __init__(self,dim): # n entity
        self.dim = dim
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.2)
        self.sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))
        self.build_network()

    def build_network(self):
        '''input'''
        with tf.name_scope('input'):
            self.s = tf.placeholder(tf.float32, shape=[None, self.dim * 2], name='states')
            self.w = tf.placeholder(tf.float32, shape=[None, self.dim], name='w_code')  #w_code dim=one entity dim
            self.w_single = tf.placeholder(tf.float32, shape=[self.dim], name='w_code_single')
            self.ai = tf.placeholder(tf.float32, shape=[None, 1], name='attention_i')
            self.aj = tf.placeholder(tf.float32, shape=[None, 1], name='attention_j')
            self.sig_ai = tf.sigmoid(self.ai)
            self.sig_aj = tf.sigmoid(self.aj)
            self.all = self.sig_ai*self.sig_aj*self.g_theta(self.s,self.w)
            #print self.all
            self.all_sum = tf.reduce_sum(self.all,axis=0)
            #print self.all_sum
            self.f_value = self.f_theta(self.all_sum,self.w_single)
            self.energy = tf.pow(self.f_value,2)
        self.sess.run(tf.global_variables_initializer())


    def g_theta(self,o_ij , w,scope='g_theta', reuse=tf.AUTO_REUSE):
        with tf.variable_scope(scope, reuse=reuse) as scope:
            #print tf.concat([o_ij, w], axis=1)
            g_1 = fc(tf.concat([o_ij, w], axis=1), 128, name='g_1')
            g_2 = fc(g_1, 128, name='g_2')
            g_3 = fc(g_2, 128, name='g_3')
            return g_3

    def f_theta(self, sum, w, scope='f_theta', reuse=tf.AUTO_REUSE):
        with tf.variable_scope(scope, reuse=reuse) as scope:
            #print tf.concat([sum, w], axis=0)
            g_1 = fc(tf.reshape(tf.concat([sum, w], axis=0),[1,-1]), 128, name='g_1')
            g_2 = fc(g_1, 128, name='g_2')
            g_3 = fc(g_2, 1, name='g_3')
            return g_3

    def forward(self,states,w,w_single,ai,aj):
        e_value = self.sess.run(self.energy, feed_dict={self.s: states,self.w: w,self.w_single:w_single,self.ai:ai,self.aj:aj})
        return e_value



if __name__ == '__main__':
    random.seed(1)
    tf.set_random_seed(1)
    ef = EnergyFunction(4)
    states = []
    states.append([0.5,-0.5,0.3,0.3,0.6,-0.6,0.3,0.3])
    states.append([0.5, -0.5, 0.3, 0.3, 0.6, -0.6, 0.3, 0.3])
    states.append([0.5, -0.5, 0.3, 0.3, 0.6, -0.6, 0.3, 0.3])
    w_s = [0.2,0.2,0.2,0.2]
    w,ai,aj = [],[],[]
    w.append(w_s)
    w.append(w_s)
    w.append(w_s)
    ai=[[10],[0],[10]]
    aj=[[10],[10],[0]]
    c = ef.forward(states=states,w=w,w_single=w_s,ai=ai,aj=aj)
    print (c)




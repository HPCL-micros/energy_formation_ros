import os
from functools import reduce
from operator import mul
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
import ObjectEnv as oe
import random
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow.contrib.slim as slim
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

from tensorflow.python.platform import flags

FLAGS = flags.FLAGS
#flags.DEFINE_float('line_y',0.2,'test y')
flags.DEFINE_integer('lsteps',20,'langevin steps')
flags.DEFINE_float('lr',0.001,'learning rate')
flags.DEFINE_integer('batch_size',64,'batch')
flags.DEFINE_integer('batch_gen',100,'data generation size')
flags.DEFINE_integer('epochs',200,'epochs')

def fc(input, output_shape, activation_fn=tf.nn.leaky_relu, name="fc"):
    #output = slim.fully_connected(input, int(output_shape), activation_fn=activation_fn)
    output = tf.layers.dense(input,output_shape,activation=activation_fn)
    return output

def get_num_params():
    num_params = 0
    for variable in tf.trainable_variables():
        shape = variable.get_shape()
        print (shape)
        num_params += reduce(mul, [dim.value for dim in shape], 1)
    return num_params

class SimpleEnergy:  #(n*n-1)*dim*2
    def __init__(self,dim): # n entity
        self.dim = dim
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.2)
        self.sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))

    def forward(self,input,reuse=tf.AUTO_REUSE):
        with tf.variable_scope('ebm', reuse=reuse) as scope:
            g_1 = fc(input, 64, name='g_1')
            g_2 = fc(g_1, 64, name='g_2')
            #g_3 = fc(g_2, 32, name='g_3')
            #g_4 = fc(g_3, 32, name='g_4')
            g_5 = fc(g_2, 1, name='g_5')
            energy = 100.0*tf.pow(g_5, 2)
        '''
        with tf.name_scope('input'):
            self.s = tf.placeholder(tf.float32, shape=[None, self.dim * 2], name='states')
            self.a = tf.placeholder(tf.float32, shape=[None, 3], name='attentions')
            self.sig_a = tf.sigmoid(self.a)
            self.g_1 = fc(tf.concat([self.s, self.sig_a], axis=1), 64, name='g_1')
            self.g_2 = fc(self.g_1, 64, name='g_2')
            self.g_3 = fc(self.g_2, 1, name='g_3')
            self.energy = tf.pow(self.g_3,2)
        self.sess.run(tf.global_variables_initializer())

    def forward(self,states,attetions):
        e_value = self.sess.run(self.energy, feed_dict={self.s: states,self.a:attetions})
        return e_value

    #def ml_part1(self):
         '''
        return energy



if __name__ == '__main__':
    #random.seed(1)
    #tf.set_random_seed(1)
    #print FLAGS.lsteps
    batch_size = FLAGS.batch_size
    generate_batches = FLAGS.batch_gen
    epochs = FLAGS.epochs
    
    model = SimpleEnergy(2)
    x0 = oe.generate_line_two(batch_size*generate_batches)
    x_pos = tf.placeholder(tf.float32, shape=[None, 2 * 2], name='x_pos')
    x_neg = tf.placeholder(tf.float32, shape=[None, 2 * 2], name='x_neg')
    pos = [0.1,0.1,0.1,0.1]
    neg = [0.5,0.5,0.5,0.5]
    #input = []
    #input.append(pos)
    #input.append(neg)
    pos_eval = model.forward(x_pos)
    neg_eval = model.forward(x_neg)
    #c = ef.forward(states=states,attetions=)
    gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.2)
    sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))

    steps = tf.constant(0)
    c = lambda i, x: tf.less(i, FLAGS.lsteps)


    def langevin_step(counter, x_mod):
        x_mod = x_mod + tf.random_normal(tf.shape(x_mod),
                                         mean=0.0,
                                         stddev=0.005)
        #print x_mod.shape
        energy_noise = energy_start = tf.concat(
            [model.forward(
                x_mod)],
            axis=0)
        #print energy_noise.shape
        x_grad = tf.gradients(
            1.0 * energy_noise, x_mod)[0]
        energy_noise_old = energy_noise

        lr = 1
        #print x_mod.shape
        #print x_grad
        x_last = x_mod - x_grad*0.5*0.005
        #print x_last.shape
        x_mod = x_last

        x_mod = tf.clip_by_value(x_mod, -1.0, 1.0)

        counter = counter + 1

        return counter, x_mod

    def update_grad(counter,x_mod):
        energy_noise = energy_start = tf.concat(
            [model.forward(
                x_mod)],
            axis=0)
        x_grad = tf.gradients(
            1.0 * energy_noise, x_mod)[0]
        x_direction = tf.divide(x_grad,tf.norm(x_grad))
        x_next = x_mod - x_direction * 0.01
        x_next = tf.clip_by_value(x_next, -1.0, 1.0)
        # print x_last.shape
        counter = counter+1
        return counter,x_next,x_grad


    steps, x_mod = tf.while_loop(c, langevin_step, (steps, x_neg))
    update_steps = 0
    update_steps,x_next,grads = update_grad(update_steps,x_pos)
    #x_mod = x_neg
    energy_neg = model.forward(
        tf.stop_gradient(x_mod))
    energy_pos = model.forward(x_pos)
    #energy_pos_norm = tf.log(energy_pos)
    #pos_loss = tf.reduce_mean(energy_pos)
    #neg_loss = -tf.reduce_mean(energy_neg)
    #loss_ml = pos_loss + neg_loss
    loss_ml = tf.reduce_mean( tf.nn.softplus(energy_pos-energy_neg) )
    optimizer = tf.train.AdamOptimizer(learning_rate=0.001)
    #optimizer = tf.train.AdadeltaOptimizer(learning_rate=0.001)
    train_op = optimizer.minimize(loss_ml)
    sess.run(tf.global_variables_initializer())
    x0 = np.reshape(x0,(generate_batches,batch_size,2*2))
    #for epoch in range(0,epochs):
    #    input_rnd = np.random.normal(loc=0.0, scale=1.0, size=(generate_batches,batch_size,3*2))
    #    for i in range(0,generate_batches):
    #        _,loss,sample = sess.run([train_op,loss_ml,x_mod],feed_dict={x_pos:x0[i],x_neg:input_rnd[i]})
            #print("loss = "+str(loss))
    '''
    x_index = np.array([0.01*i for i in range(-100,101,1)])
    y_index = np.array([0.01*i for i in range(-100,101,1)])
    z = []
    for i in range(0,len(x_index)):
        z.append([])
        for j in range(0,len(y_index)):
            z[i].append(x_index[i]*y_index[j])
    z = np.array(z)
    fig = plt.figure()
    ax = Axes3D(fig)
    ax.plot_surface(x_index, y_index, z, rstride=1, cstride=1,cmap="rainbow")
    '''
    
    #writer = tf.summary.FileWriter("logs/", tf.get_default_graph())
    print ("langevin steps: "+str(FLAGS.lsteps))
    print ("batch size: "+str(batch_size))
    print ("generate data batches: "+str(generate_batches))
    print ("epochs: " +str(epochs))
    '''
    figs = []
    axs = []
    #plt.ion()
    for i in range(0,6):
        figs.append(plt.figure())
        axs.append(Axes3D(figs[i]))
    #fig = plt.figure()
    #fig2 = plt.figure()
    #fig3 = plt.figure()
    #ax = Axes3D(fig)
    #ax2 = Axes3D(fig2)
    #ax3 = Axes3D(fig3)
    x1 = np.linspace(-1, 1, 40)
    y1 = np.linspace(-1, 1, 40)
    x1, y1 = np.meshgrid(x1, y1)
    #z = x1**2+y1**2
    #z = np.concatenate([x1,y1],axis=1)???
    #z = sess.run([energy_pos], feed_dict={x_pos:z})
    #ax.plot_surface(x1, y1, z1, rstride=1, cstride=1, cmap='rainbow')
    #print x1.shape
    point_x = np.reshape(x1,(40*40,1))
    point_y = np.reshape(y1,(40*40,1))
    
    test_ys = []
    test_inputs = []
    #const_x = np.random.uniform(-1.0, 1.0, size=(40*40,1))
    for i in range(0,3):
       y = np.random.uniform(-1.0, 1.0)
       test_ys.append(y)
       const_y = np.reshape(np.array([y]*1600),(40*40,1))
       const_x = np.reshape(np.array([0.2]*1600),(40*40,1))
       test_inputs.append(np.concatenate((const_x, const_y, point_x, point_y), axis=1))
    print ("test ys:")
    print (test_ys)
    #cy = 0.5
    #const_x = np.reshape(np.array([0.3]*1600),(40*40,1))
    
    #const_y = np.reshape(np.array([cy]*1600),(40*40,1))
    #test_input = np.concatenate((const_x,const_y,const_x,const_y,point_x,point_y),axis=1)
    #test_input = np.concatenate((const_x, const_y, point_x, point_y), axis=1)
    #z2 = point_x**2+point_y**2
    zs = []
    for i in range(0,3):
        zs.append(sess.run([energy_pos], feed_dict={x_pos:test_inputs[i]}))
        axs[i].plot_surface(x1, y1, np.reshape(zs[i], (40, 40)), rstride=1, cstride=1, cmap='rainbow')
    #plt.show()
    #plt.ioff()
    '''
    print ("start training...")
    print ("total parameters: "+str(get_num_params()))

    for epoch in range(0, epochs):
        #input_rnd = np.random.normal(loc=0.0, scale=1.0, size=(generate_batches,batch_size,2*2))
        input_rnd = np.random.uniform(-1.0, 1.0, size=(generate_batches, batch_size, 2 * 2))
        for i in range(0,generate_batches):
            _,loss,sample,e_neg = sess.run([train_op,loss_ml,x_mod,energy_neg],feed_dict={x_pos:x0[i],x_neg:input_rnd[i]})
            if epoch%10==0 and i == 0:
                print ("epoch = "+str(epoch)+" loss = "+str(loss)+" e_neg="+str(np.mean(e_neg)))
                #print sample[0]
    env = oe.ObjectEnv()
    x = [0.5,0.6,-0.3,-0.3]
    env.set_from_x_short(x)
    env.show()
    plt.waitforbuttonpress()
    for i in range(0,200):
        x,x_grads,e_x = sess.run([x_next,grads,energy_pos],feed_dict={x_pos:[x]})
        print ("energy = "+str(e_x))
        #print (x)
        #print (x_grads)
        x = np.squeeze(x)
        env.clear()
        env.set_from_x_short(x)
        env.show()
        plt.waitforbuttonpress()
    '''
    z_results = []
    for i in range(0,3):
        z_results.append(sess.run([energy_pos], feed_dict={x_pos: test_inputs[i]})[0])
        axs[i+3].plot_surface(x1, y1, np.reshape(z_results[i], (40, 40)), rstride=1, cstride=1, cmap='rainbow')
        #ax[i+3].plot_surface(x1, y1, np.reshape(z_results[i], (40, 40)), rstride=1, cstride=1, cmap='rainbow')
        print ("position:" +str(test_inputs[i][0])+str(test_inputs[i][39])+str(test_inputs[i][1519])+str(test_inputs[i][1599]))
        print ("energy:"+str(z_results[i][0])+str(z_results[i][39])+str(z_results[i][1519])+str(z_results[i][1599]))
    print ("test ys:")
    print (test_ys)
    print ("test line for case 0:")
    cx_test = np.reshape(np.array([0.2]*40),(40,1))
    cy_test = np.reshape(np.array([test_ys[0]]*40),(40,1))
    y_test = np.reshape(np.linspace(-1, 1, 40),(40,1))
    x_test = np.reshape(np.array([-0.3]*40),(40,1))
    input_test=np.concatenate((cx_test, cy_test, x_test, y_test), axis=1)
    z_line = sess.run([energy_pos], feed_dict={x_pos: input_test})[0]
    z_line = np.reshape(z_line,(40))
    print (z_line)
    fig = plt.figure()
    plt.plot(y_test,z_line)
    
    #def idea_energy(point_x,point_y):
    #    return (point_y-cy)**2

    #z3 = idea_energy(point_x,point_y)
    #ax3.plot_surface(x1, y1, np.reshape(z3, (40, 40)), rstride=1, cstride=1, cmap='rainbow')
    #plt.ioff()
    plt.show()
    #plt.waitforbuttonpress()
    '''




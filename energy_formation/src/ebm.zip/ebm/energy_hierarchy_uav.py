import os
from functools import reduce
from operator import mul
#os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
import ObjectEnv as oe
import random
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow.contrib.slim as slim
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
from EBMloader import EnergyLoader
import lpvf
from tensorflow.python.platform import flags

min_index = -5.0
max_index = 5.0
use_anchor = False
shuffle_points = False
squire_size = 4.0
triangle_size = 2.0
velocity = 0.05
v0 = 1.0
rd = 1.0
#TODO: not implemented. waiting for localization.
if __name__ == '__main__':
    if not use_anchor:
        squire_energy = EnergyLoader('model/fixed_squire4_ns',False)
        triangle_energy = EnergyLoader('model/fixed_triangle2_ns',False)
        x0 = oe.generate_fixed_triangle(1000, shuffle_points, min_index, max_index,c=triangle_size)
        x0 = np.reshape(x0, (1000, 3 * 2))
        _, _, e_x0_tri = triangle_energy.optimize(x0)
        x0 = oe.generate_fixed_squire(1000, shuffle_points, min_index, max_index, c=squire_size)
        x0 = np.reshape(x0, (1000, 4 * 2))
        _, _, e_x0_squ = squire_energy.optimize(x0)
        e_squ_mean = np.mean(e_x0_squ)
        e_tri_mean = np.mean(e_x0_tri)
        print("energy mean: squ="+str(np.mean(e_x0_squ))+",tri="+str(np.mean(e_x0_tri)))
        squire_x = np.random.uniform(min_index, max_index, size=(4 * 2)) # squire points
        x = np.random.uniform(min_index, max_index, size=(4, 2 * 2)) # triangle points
        env = oe.ObjectEnv(min_index-rd*3, max_index+rd*3)
        env.clear()
        x_squeezing = np.reshape(x, (4 * 2 * 2))
        x_squeezing = np.concatenate([x_squeezing, squire_x], axis=0)
        uav_x = np.array(x_squeezing) - 0.5
        uav_yaw = np.array([0.0] * 12)
        uav_w = np.array([0.0] * 12)
        uav_v = np.array([v0] * 12)
        uav_phi = np.array([-0.75 * np.pi] * 12)
        #env.set_from_x_short(x_squeezing.tolist(),size=5)
        env.set_from_x_short(uav_x, marker='^', size=10)
        env.show()
        plt.waitforbuttonpress()
        for i in range(0,2000):
            squire_x = squire_x.tolist()
            squire_x_new, squire_x_grads, e_x = squire_energy.optimize([squire_x])
            squire_x = np.squeeze(squire_x)
            squire_x_grads = np.squeeze(squire_x_grads)
            vel = squire_x_grads / np.linalg.norm(squire_x_grads) * velocity
            current_energy = np.mean(e_x)
            #print(current_energy)
            #print(e_x0_squ)
            if current_energy < 10.0 * e_squ_mean:
                vel = vel * current_energy / (10.0 * e_squ_mean)
            squire_x = squire_x - vel
            tri = np.reshape(squire_x,(4,2))
            for j in range(0,4):
                tri_x = np.concatenate([tri[j],x[j]])
                triangle_x, triangle_x_grads, e_x = triangle_energy.optimize([tri_x])
                triangle_x = np.squeeze(triangle_x)
                triangle_x_grads = np.squeeze(triangle_x_grads)
                vel = triangle_x_grads / np.linalg.norm(triangle_x_grads) * velocity
                current_energy = np.mean(e_x)
                if current_energy < 10.0 * e_tri_mean:
                    vel = vel * current_energy / (10.0 * e_tri_mean)
                tri_x = tri_x - vel
                for k in range(2,6):
                    #x[j][k-2]=triangle_x[k]
                    x[j][k - 2] = tri_x[k]
            x_squeezing = np.reshape(x, (4 * 2 * 2))
            x_squeezing = np.concatenate([x_squeezing, squire_x], axis=0)

            for j in range(0, 12):
                u = lpvf.lpvf_yaw_control(px=uav_x[2 * j], py=uav_x[2 * j + 1], yaw=uav_yaw[j], v=v0, w=uav_w[j],
                                          tx=x_squeezing[2 * j], ty=x_squeezing[2 * j + 1], rd=rd)
                # v_list = lpvf.yaw_sync_control(uav_phi,v0,Kdv=0.05)
                px, py, yaw = lpvf.diff_drive_iter(px=uav_x[2 * j], py=uav_x[2 * j + 1], yaw=uav_yaw[j], v=uav_v[j],
                                                   w=uav_w[j], step=0.05)
                uav_x[2 * j] = px
                uav_x[2 * j + 1] = py
                uav_yaw[j] = yaw
                uav_w[j] = u
                uav_phi[j] = np.arctan2(uav_x[2 * j + 1] - x_squeezing[2 * j + 1], uav_x[2 * j] - x_squeezing[2 * j])
            uav_v = lpvf.phi_sync_control(phi_list=uav_phi, v0=v0, Kdv=0.05)
            env.clear()
            #env.set_from_x_short(x_squeezing.tolist(),size=5)
            env.set_from_x_short(uav_x, marker='^', size=10)
            env.show()
            plt.pause(0.02)
        plt.waitforbuttonpress()
        exit(1)
    squire_energy = EnergyLoader('model/fixed_squire_anchor3_ns')
    triangle_energy = EnergyLoader('model/fixed_triangle_anchor1_ns')
    #test squire
    squire_x = np.random.uniform(min_index, max_index, size=(4 * 2))
    squire_anchor = [-2.0,-2.0]
    x = np.random.uniform(min_index, max_index, size=(4, 3 * 2))
    env = oe.ObjectEnv(min_index, max_index)
    env.clear()
    x_squeezing=np.reshape(x,(4*3*2))
    x_squeezing=np.concatenate([x_squeezing,squire_x],axis=0)
    env.set_from_x_short(x_squeezing.tolist())
    env.show()
    plt.waitforbuttonpress()
    for i in range(0, 500):
        squire_x = squire_x.tolist()
        squire_x, squire_x_grads, e_x =squire_energy.optimize([squire_x],[squire_anchor]) #sess.run([x_next, grads, energy_pos], feed_dict={x_pos: [x], x_anchor: [test_anchor]})
        print("energy = " + str(e_x) + " anchor = " + str(squire_anchor))
        squire_x = np.squeeze(squire_x)
        angular_xs = []
        for j in range(0,4):
            triangle_x = list(x[j])
            #squire_x=np.array([-3,-1,-3,1,1,-1,1,1])
            triangle_x,triangle_x_grads,e_x =triangle_energy.optimize([triangle_x],[[squire_x[2*j],squire_x[2*j+1]]])
            triangle_x = np.squeeze(triangle_x)
            angular_xs.append(triangle_x.tolist())
        x = np.array(angular_xs)
        x_squeezing = np.reshape(x, (4 * 3 * 2))
        #x_squeezing = np.concatenate([x_squeezing, squire_x], axis=0)

        env.clear()
        env.set_from_x_short(x_squeezing.tolist())
        env.show()
        #plt.waitforbuttonpress()
        plt.pause(0.02)
    plt.waitforbuttonpress()